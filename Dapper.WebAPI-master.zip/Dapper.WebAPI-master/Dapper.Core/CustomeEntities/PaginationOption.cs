﻿namespace Dapper.Core.CustomEntities
{
    public class PaginationOption
    {
        public int DefaultPageSize { get; set; }
        public int DefaultPageNumber { get; set; }
    }
}
