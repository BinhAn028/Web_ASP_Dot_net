﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dapper.Core.Enumerations
{
    public enum ConnectionType
    {
        Connection1,
        Connection2
    }
}
